<?php
/**
 * Custom css file.
 *
 * @link http://shapedplugin.com
 * @since 2.0.0
 *
 * @package Testimonial_free.
 * @subpackage Testimonial_free/includes.
 */

$setting_options = get_option( 'sp_testimonial_pro_options' );
$custom_css      = $setting_options['custom_css'];
